#!/system/bin/sh
ui_print "OnePlus 15 Spoofer For All Devices"
ui_print "By: MRX7014"
ui_print "Enjoy :)"
sleep 1